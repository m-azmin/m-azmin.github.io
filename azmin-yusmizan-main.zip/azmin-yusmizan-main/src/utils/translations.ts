
export const translations = {
  en: {
    nav: {
      about: 'About',
      projects: 'Projects',
      internships: 'Experience',
      education: 'Education',
      skills: 'Skills',
      hobbies: 'Hobbies',
      contact: 'Contact'
    },
    hero: {
      greeting: 'Hello, I\'m',
      title: 'Electrical Engineering Student',
      subtitle: 'Passionate about innovative engineering solutions and sustainable technology',
      cta: 'Get In Touch'
    },
    about: {
      title: 'About Me',
      description: '21-year-old Malaysian international student in Electrical Engineering at INSA Lyon, passionate about embedded electronics and intelligent systems development. Currently seeking an internship to apply my skills in circuit design and embedded programming.',
      values: {
        innovation: 'Innovation',
        innovationDesc: 'Always exploring new technologies and engineering approaches',
        quality: 'Quality',
        qualityDesc: 'Committed to excellence in engineering design and analysis',
        collaboration: 'Collaboration',
        collaborationDesc: 'Strong team player with excellent communication skills'
      }
    },
    education: {
      title: 'Education',
      subtitle: 'My academic journey in electrical engineering and related fields',
      relevantCourses: 'Relevant Courses',
      achievements: 'Achievements'
    },
    projects: {
      title: 'My Projects',
      viewProject: 'View Project',
      viewCode: 'View Code'
    },
    internships: {
      title: 'Experience',
      present: 'Present'
    },
    skills: {
      title: 'Skills & Technologies',
      frontend: 'Frontend',
      backend: 'Backend',
      tools: 'Tools & Others'
    },
    hobbies: {
      title: 'Hobbies & Interests',
      description: 'When I\'m not studying or working on projects, you can find me:'
    },
    contact: {
      title: 'Let\'s Connect',
      subtitle: 'Feel free to reach out for collaborations or just a friendly chat!',
      form: {
        name: 'Your Name',
        email: 'Your Email',
        message: 'Your Message',
        send: 'Send Message'
      }
    }
  },
  ms: {
    nav: {
      about: 'Tentang',
      projects: 'Projek',
      internships: 'Pengalaman',
      education: 'Pendidikan',
      skills: 'Kemahiran',
      hobbies: 'Hobi',
      contact: 'Hubungi'
    },
    hero: {
      greeting: 'Halo, saya',
      title: 'Pelajar Kejuruteraan Elektrik',
      subtitle: 'Bersemangat tentang penyelesaian kejuruteraan inovatif dan teknologi lestari',
      cta: 'Hubungi Saya'
    },
    about: {
      title: 'Tentang Saya',
      description: 'Pelajar antarabangsa Malaysia berumur 21 tahun dalam jurusan Kejuruteraan Elektrik di INSA Lyon, bersemangat dalam bidang elektronik terbenam dan pembangunan sistem pintar. Sedang mencari latihan industri untuk mengaplikasikan kemahiran saya dalam reka bentuk litar dan pengaturcaraan terbenam.',
      values: {
        innovation: 'Inovasi',
        innovationDesc: 'Sentiasa meneroka teknologi dan pendekatan kejuruteraan baru',
        quality: 'Kualiti',
        qualityDesc: 'Komited kepada kecemerlangan dalam reka bentuk dan analisis kejuruteraan',
        collaboration: 'Kerjasama',
        collaborationDesc: 'Pemain pasukan yang kuat dengan kemahiran komunikasi yang baik'
      }
    },
    education: {
      title: 'Pendidikan',
      subtitle: 'Perjalanan akademik saya dalam kejuruteraan elektrik dan bidang berkaitan',
      relevantCourses: 'Kursus Berkaitan',
      achievements: 'Pencapaian'
    },
    projects: {
      title: 'Projek Saya',
      viewProject: 'Lihat Projek',
      viewCode: 'Lihat Kod'
    },
    internships: {
      title: 'Pengalaman',
      present: 'Kini'
    },
    skills: {
      title: 'Kemahiran & Teknologi',
      frontend: 'Frontend',
      backend: 'Backend',
      tools: 'Alatan & Lain-lain'
    },
    hobbies: {
      title: 'Hobi & Minat',
      description: 'Apabila saya tidak belajar atau bekerja pada projek, anda boleh menjumpai saya:'
    },
    contact: {
      title: 'Mari Berhubung',
      subtitle: 'Jangan ragu untuk menghubungi untuk kerjasama atau sekadar berbual!',
      form: {
        name: 'Nama Anda',
        email: 'Email Anda',
        message: 'Mesej Anda',
        send: 'Hantar Mesej'
      }
    }
  },
  fr: {
    nav: {
      about: 'À propos',
      projects: 'Projets',
      internships: 'Expérience',
      education: 'Éducation',
      skills: 'Compétences',
      hobbies: 'Loisirs',
      contact: 'Contact'
    },
    hero: {
      greeting: 'Bonjour, je suis',
      title: 'Étudiant en Génie Électrique',
      subtitle: 'Passionné par les solutions d\'ingénierie innovantes et la technologie durable',
      cta: 'Me Contacter'
    },
    about: {
      title: 'À Propos de Moi',
      description: 'Étudiant international malaisien de 21 ans en Génie Électrique à l’INSA Lyon, passionné par l’électronique embarquée et le développement de systèmes intelligents. À la recherche d’un stage pour appliquer mes compétences en conception de circuits et programmation embarquée.',
      values: {
        innovation: 'Innovation',
        innovationDesc: 'Toujours explorer de nouvelles technologies et approches d\'ingénierie',
        quality: 'Qualité',
        qualityDesc: 'Engagé à l\'excellence dans la conception et l\'analyse d\'ingénierie',
        collaboration: 'Collaboration',
        collaborationDesc: 'Excellent joueur d\'équipe avec d\'excellentes compétences de communication'
      }
    },
    education: {
      title: 'Éducation',
      subtitle: 'Mon parcours académique en génie électrique et domaines connexes',
      relevantCourses: 'Cours Pertinents',
      achievements: 'Réalisations'
    },
    projects: {
      title: 'Mes Projets',
      viewProject: 'Voir le Projet',
      viewCode: 'Voir le Code'
    },
    internships: {
      title: 'Expérience',
      present: 'Présent'
    },
    skills: {
      title: 'Compétences & Technologies',
      frontend: 'Frontend',
      backend: 'Backend',
      tools: 'Outils & Autres'
    },
    hobbies: {
      title: 'Loisirs & Intérêts',
      description: 'Quand je n\'étudie pas ou ne travaille pas sur des projets, vous pouvez me trouver:'
    },
    contact: {
      title: 'Connectons-nous',
      subtitle: 'N\'hésitez pas à me contacter pour des collaborations ou juste pour discuter!',
      form: {
        name: 'Votre Nom',
        email: 'Votre Email',
        message: 'Votre Message',
        send: 'Envoyer le Message'
      }
    }
  },
  es: {
    nav: {
      about: 'Acerca de',
      projects: 'Proyectos',
      internships: 'Experiencia',
      education: 'Educación',
      skills: 'Habilidades',
      hobbies: 'Aficiones',
      contact: 'Contacto'
    },
    hero: {
      greeting: 'Hola, soy',
      title: 'Estudiante de Ingeniería Eléctrica',
      subtitle: 'Apasionado por soluciones de ingeniería innovadoras y tecnología sostenible',
      cta: 'Contáctame'
    },
    about: {
      title: 'Acerca de Mí',
      description: 'Estudiante internacional malasio de 21 años en Ingeniería Eléctrica en INSA Lyon, apasionado por la electrónica embebida y el desarrollo de sistemas inteligentes. En busca de una práctica para aplicar mis competencias en diseño de circuitos y programación embebida.',
      values: {
        innovation: 'Innovación',
        innovationDesc: 'Siempre explorando nuevas tecnologías y enfoques de ingeniería',
        quality: 'Calidad',
        qualityDesc: 'Comprometido con la excelencia en diseño y análisis de ingeniería',
        collaboration: 'Colaboración',
        collaborationDesc: 'Excelente jugador de equipo con habilidades de comunicación sobresalientes'
      }
    },
    education: {
      title: 'Educación',
      subtitle: 'Mi viaje académico en ingeniería eléctrica y campos relacionados',
      relevantCourses: 'Cursos Relevantes',
      achievements: 'Logros'
    },
    projects: {
      title: 'Mis Proyectos',
      viewProject: 'Ver Proyecto',
      viewCode: 'Ver Código'
    },
    internships: {
      title: 'Experiencia',
      present: 'Presente'
    },
    skills: {
      title: 'Habilidades & Tecnologías',
      frontend: 'Frontend',
      backend: 'Backend',
      tools: 'Herramientas & Otros'
    },
    hobbies: {
      title: 'Aficiones & Intereses',
      description: 'Cuando no estoy estudiando o trabajando en proyectos, puedes encontrarme:'
    },
    contact: {
      title: 'Conectemos',
      subtitle: '¡No dudes en contactarme para colaboraciones o simplemente para charlar!',
      form: {
        name: 'Tu Nombre',
        email: 'Tu Email',
        message: 'Tu Mensaje',
        send: 'Enviar Mensaje'
      }
    }
  }
};
